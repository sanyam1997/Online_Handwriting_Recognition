import csv
with open( 'Project/Dataset/train.csv' , 'rb') as csvfile:
    reader = csv.reader( csvfile , delimiter = ';' )
    i = 0 
    for i in range( 106 ) :
        row = next(reader)
        i+= 1
    row = next( reader )
    
i = 0
points_x = [ ]
points_y = [ ]
for i in range( 12 ) :
    points_x.append( row[ 2 ][ 3 + i*26 ] + row[ 2 ][ 4 + i*26 ] + row[ 2 ][ 5 + i*26 ] )
    points_y.append( row[ 2 ][ 11 + i*26 ] + row[ 2 ][ 12 + i*26 ] + row[ 2 ][ 13 + i*26 ] )
    i+= 1

import matplotlib.pyplot as plt
import numpy as np

arrX = [ ]
arrY = [ ]

i = 0 
for i in range( 26 ) :
    arrX.append( row[ 2 ][ 3 + i*37 ] + row[ 2 ][ 4 + i*37 ] + row[ 2 ][ 5 + i*37 ] )
    arrY.append( row[ 2 ][ 11 + i*37 ] + row[ 2 ][ 12 + i*37 ] + row[ 2 ][ 13 + i*37 ] )
    
fig0 = plt.figure( ) 
ax0 = fig0.add_subplot( 1 , 1 , 1 )
ax0.scatter( arrX , arrY ) 
#plt.show( )

arrx1 = [ ]
arry1 = [ ]

i = 0 
for i in range( 46 ) :
    arrx1.append( row[ 2 ][ 967 + i*37 ] + row[ 2 ][ 968 + i*37 ] + row[ 2 ][ 969 + i*37 ] )
    arry1.append( row[ 2 ][ 975 + i*37 ] + row[ 2 ][ 976 + i*37 ] + row[ 2 ][ 977 + i*37 ] )
    i+= 1


fig1 = plt.figure()
#ax1 = fig1.add_subplot(1, 1, 1)
ax0.scatter( arrx1 , arry1 ) 
plt.show()
