import math
import numpy as np
from numpy.linalg import inv
from numpy.linalg import norm
from scipy.stats.stats import pearsonr   

arrX = [ ]
arrY = [ ]
arrx1 = [ ]
arry1 = [ ]
i = 0
#for i in range( f_obj[ 0 ][ 0 ].length( )( ) ) :
#    arrX[ i ] = f_obj[ 0 ][ 0 ][ i ]
#    i+= 1
#for i in range( f_obj[ 0 ][ 1 ].length( )( ) ) :
#    arrY[ i ] = f_obj[ 0 ][ 1 ][ i ]
#    i+= 1
x1 = 0
y1 = 0
x0 = 100000000000
y0 = 100000000000

#max and min value
i = 0 
for i in range( len( arrX ) ) :
    if( arrX[ i ] > x1 ) :
        x1 = arrX[ i ]
    if( arrX[ i ] < x0 ) :
        x0 = arrY[ i ]
    if( arrY[ i ] > y1 ) :
        y1 = arrY[ i ]
    if( arrY[ i ] < y0 ) :
        y0 = arrY[ i ]
    i+= 1
i = 0 
#scaling to units 
for i in range( len( arrX ) ) :
    arrX[ i ] = ( ( arrX[ i ] - x0 )/( x1 - x0 ) )*1000 
    arrY[ i ] = ( ( arrY[ i ] - y0 )/( y1 - y0 ) )*1000 
    i+= 1
#smoothing
i = 0
for i in range( len( arrX ) - 2 ) :
    arrX[ i + 1 ] = ( arrX[ i ] + arrX[ i + 1 ] + arrX[ i + 2 ] ) / 3
    arrY[ i + 1 ] = ( arrY[ i ] + arrY[ i + 1 ] + arrY[ i + 2 ] ) / 3
    i += 1
i = 0 
for i in range( len( arrX ) - 2 ) :
    arrX[ i + 1 ] = ( arrX[ i ] + arrX[ i + 1 ] + arrX[ i + 2 ] ) / 3
    arrY[ i + 1 ] = ( arrY[ i ] + arrY[ i + 1 ] + arrY[ i + 2 ] ) / 3
    i += 1

arrx = [ ]
arry = [ ]
j = 0
k = 0
arrx[ j ] = arrX[ 0 ]
arry[ k ] = arrY[ 0 ]
i+= 1
for i in range( len( arrX ) - 2 ) :
    if( ( arrX[ i + 1 ] < arrX[ i ] )&( arrX[ i + 1 ] < arrX[ i + 2 ] ) ) :
        j+= 1
        arrx[ j ] = arrX[ i + 1 ]
        arry[ j ] = arrY[ i + 1 ]
    if( ( arrX[ i + 1 ] > arrX[ i ] )&( arrX[ i + 1 ] > arrX[ i + 2 ] ) ) :
        j+= 1
        arrx[ j ] = arrX[ i + 1 ]
        arry[ j ] = arrY[ i + 1 ]
    if( ( arrY[ i + 1 ] < arrY[ i ] )&( arrY[ i + 1 ] < arrY[ i + 2 ] ) ) :
        j+= 1
        arrx[ j ] = arrX[ i + 1 ]
        arry[ j ] = arrY[ i + 1 ]
    if( ( arrY[ i + 1 ] > arrY[ i ] )&( arrY[ i + 1 ] > arrY[ i + 2 ] ) ) :
        j+= 1
        arrx[ j ] = arrX[ i + 1 ]
        arry[ j ] = arrY[ i + 1 ]
    if( ( arrX[ i + 1 ] + arrY[ i + 1 ] ) < ( arrX[ i + 2 ] + arrY[ i + 2 ] )&( ( arrX[ i + 1 ] + arrY[ i + 1 ] ) < ( arrX[ i ] + arrY[ i ] ) ) ) :
        j+= 1
        arrx[ j ] = arrX[ j + 1 ]
        arry[ j ] = arry[ j + 1 ]
    if( ( arrX[ i + 1 ] + arrY[ i + 1 ] ) > ( arrX[ i + 2 ] + arrY[ i + 2 ] )&( ( arrX[ i + 1 ] + arrY[ i + 1 ] ) > ( arrX[ i ] + arrY[ i ] ) ) ) :
        j+= 1 
        arrx[ j ] = arrX[ j + 1 ]
        arry[ j ] = arry[ j + 1 ]
    if( ( arrX[ i + 1 ] - arrY[ i + 1 ] ) < ( arrX[ i + 2 ] - arrY[ i + 2 ] )&( ( arrX[ i + 1 ] - arrY[ i + 1 ] ) < ( arrX[ i ] - arrY[ i ] ) ) ) :
        j+= 1
        arrx[ j ] = arrX[ j + 1 ]
        arry[ j ] = arry[ j + 1 ]
    if( ( arrX[ i + 1 ] - arrY[ i + 1 ] ) > ( arrX[ i + 2 ] - arrY[ i + 2 ] )&( ( arrX[ i + 1 ] - arrY[ i + 1 ] ) > ( arrX[ i ] - arrY[ i ] ) ) ) :
        j+= 1
        arrx[ j ] = arrX[ j + 1 ]
        arry[ j ] = arry[ j + 1 ]
    i+= 1
    
j+= 1
arrx[ j ] = arrX[ len( arrX ) - 1 ]
arry[ j ] = arrY[ len( arry ) - 1 ]    
    
maxx = 0
maxy = 0
minx = 1000000
miny = 1000000
for i in range( len( arrx ) ) :
    maxx = max( maxx , arrx[ i ] )
    maxy = max( maxy , arry[ i ] )
    minx = min( minx , arrx[ i ] )
    miny = min( miny , arry[ i ] )

xd = 0
yd = 0
i = 0

for i in range( len( arrx ) - 2 ) :
    xd = max( min( abs( arrx[ i + 1 ] - arrx[ 0 ] ) , abs( arrx[ i + 1 ] - arrx[ arrx.length( ) - 1 ] ) ) , xd )
    yd = max( min( abs( arry[ i + 1 ] - arry[ 0 ] ) , abs( arry[ i + 1 ] - arrx[ arry.length( ) - 1 ] ) ) , yd )

i = 0
    
ans = np.array( )
for i in range ( 9 ) :
    ans[ i ] = 1

s = 0
f = 0
for i in range( len( arrx ) ) :
    i+= 1
    if( ( abs( arrx[ 0 ] - arrx[ len( arrx ) - 1 ] ) < 20 )&( abs( arrx[ 0 ] - arrx[ len( arrx ) - 1 ] ) < 20 ) ) :
        ans[ 0 ] = 1
    elif( ( abs( arrx[ 0 ] - arrx[ len( arrx ) - 1 ] ) < 20 )&( min( ( maxx - arrx[ 0 ] ) ,( maxx - arrx[ len( arrx ) - 1 ] ) ) == 0 ) ) :
        ans[ 1 ] = 1
    elif( ( abs( arrx[ 0 ] - arrx[ len( arrx ) - 1 ] ) < 20 )&( min( ( minx - arrx[ 0 ] ) ,( minx - arrx[ len( arrx ) - 1 ] ) ) == 0 ) ) :
        ans[ 2 ] = 1
    elif( ( abs( arry[ 0 ] - arry[ len( arry ) - 1 ] ) < 20 )&( min( ( maxy - arry[ 0 ] ) ,( maxy - arry[ len( arry ) - 1 ] ) ) == 0 ) ) :
        ans[ 3 ] = 1
    elif( ( abs( arry[ 0 ] - arry[ len( arry ) - 1 ] ) < 20 )&( min( ( miny - arry[ 0 ] ) ,( miny - arry[ len( arry ) - 1 ] ) ) == 0 ) ) :
        ans[ 4 ] = 1
    elif ( ( ( minx - arrx[ 0 ] ) < 5 )&( ( maxx - arrx[ len( arrx ) - 1 ] ) < 5 )&( ( miny - arry[ 0 ] ) < 5 )&( ( maxy - arry[ len( arry ) - 1 ] ) < 5 ) ) :
        ans[ 5 ] = 1
    elif( ( ( minx - arrx[ 0 ] ) < 5 )&( ( maxx - arrx[ len( arrx ) - 1 ] ) < 5 )&( ( maxy - arry[ 0 ] ) < 5 )&( ( miny - arry[ len( arry ) - 1 ] ) < 5 ) ) :
         ans[ 6 ] = 1
    elif( ( ( maxx - arrx[ 0 ] ) < 5 )&( ( minx- arrx[ len( arrx ) - 1 ] ) < 5 )&( ( miny - arry[ 0 ] ) < 5 )&( ( maxy - arry[ len( arry ) - 1 ] ) < 5 ) ) :
         ans[ 7 ] = 1
    elif( ( ( maxx - arrx[ 0 ] ) < 5 )&( ( minx - arrx[ len( arrx ) - 1 ] ) < 5 )&( ( maxy - arry[ 0 ] ) < 5 )&( ( miny - arry[ len( arry ) - 1 ] ) < 5 ) ) :
        ans[ 8 ] = 1
    if( i == stroke ) :
        s+= 1
    else :
        f+= 1
    
#runtime scenario
# a self-implemented method meant for just one symbol
# for + sign in particular
for i in range( len( arrx )/10 ) :
    if( ( arrx[ i + 20 ] - arrx[ i ] ) > 20*( arry[ i + 20 ] - arry[ i ] ) )&( ( arry1[ i + 20 ] - arry1[ i ] ) > ( arrx1[ i + 20 ] - arrx1[ i ] ) ) :
        s += 1
    else :
        f += 1
        
accuracy = s/( s+f )
print s , f , accuracy
