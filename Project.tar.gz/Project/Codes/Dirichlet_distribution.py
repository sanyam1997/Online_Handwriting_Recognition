import math
import numpy as np
import numpy.linalg.inv as inverse
import numpy.linalg.norm as dist
import numpy.array.var as sig
from scipy.stats.stats import pearsonr   

arrX = [ ] , arrY = [ ]
i = 0
for i in range( f_obj[ 0 ].length()( ) ) :
    arrX[ i ] = f_obj[ 0 ][ i ][ 1 ]
    arrY[ i ] = f_obj[ 0 ][ i ][ 1 ]
    i+= 1
x1 = 0
y1 = 0
x0 = 100000000000
y0 = 100000000000

#max and min value
i = 0 
for i in range( arrX.length( ) ) :
    if( arrX[ i ] > x1 )
        x1 = arrX[ i ]
    if( arrX[ i ] < x0 )
        x0 = arrY[ i ]
    if( arrY[ i ] > y1 )
        y1 = arrY[ i ]
    if( arrY[ i ] < y0 )
        y0 = arrY[ i ]
    i+= 1
i = 0 
#scaling to units 
for i in range( arrX.length( ) ) :
    arrX[ i ] = ( ( arrX[ i ] - x0 )/( x1 - x0 ) )*100 
    arrY[ i ] = ( ( arrY[ i ] - y0 )/( y1 - y0 ) )*100 
    i+= 1
#smoothing
i = 0
for i in range( arrX.length( ) - 2 ) :
    arrX[ i + 1 ] = ( arrX[ i ] + arrX[ i + 1 ] + arrX[ i + 2 ] ) / 3
    arrY[ i + 1 ] = ( arrY[ i ] + arrY[ i + 1 ] + arrY[ i + 2 ] ) / 3
    i += 1
i = 0 
for i in range( arrX.length( ) - 2 )
    arrX[ i + 1 ] = ( arrX[ i ] + arrX[ i + 1 ] + arrX[ i + 2 ] ) / 3
    arrY[ i + 1 ] = ( arrY[ i ] + arrY[ i + 1 ] + arrY[ i + 2 ] ) / 3
    i += 1
x , y 
x = sum( arrX ) / arrX.length( )
y = sum( arrY ) / arrY.length( )

arrx = np.array( ) , arry = np.array( )
j = 0
arrx[ j ] = arrX[ 0 ]
arry[ k ] = arrY[ 0 ]
i+= 1
for i in range( arrX.length( ) - 2 ) :
    if( ( arrX[ i + 1 ] < arrX[ i ] )&&( arrX[ i + 1 ] < arrX[ i + 2 ] ) )
        j+= 1
        arrx[ j ] = arrX[ i + 1 ]
        arry[ j ] = arrY[ i + 1 ]
    if( ( arrX[ i + 1 ] > arrX[ i ] )&&( arrX[ i + 1 ] > arrX[ i + 2 ] ) )
        j+= 1
        arrx[ j ] = arrX[ i + 1 ]
        arry[ j ] = arrY[ i + 1 ]
    if( ( arrY[ i + 1 ] < arrY[ i ] )&&( arrY[ i + 1 ] < arrY[ i + 2 ] ) )
        j+= 1
        arrx[ j ] = arrX[ i + 1 ]
        arry[ j ] = arrY[ i + 1 ]
    if( ( arrY[ i + 1 ] > arrY[ i ] )&&( arrY[ i + 1 ] > arrY[ i + 2 ] ) )
        j+= 1
        arrx[ j ] = arrX[ i + 1 ]
        arry[ j ] = arrY[ i + 1 ]
    if( ( arrX[ i + 1 ] + arrY[ i + 1 ] ) < ( arrX[ i + 2 ] + arrY[ i + 2 ] ) && ( ( arrX[ i + 1 ] + arrY[ i + 1 ] ) < ( arrX[ i ] + arrY[ i ] ) ) )
        j+= 1
        arrx[ j ] = arrX[ j + 1 ]
        arry[ j ] = arry[ j + 1 ]
    if( ( arrX[ i + 1 ] + arrY[ i + 1 ] ) > ( arrX[ i + 2 ] + arrY[ i + 2 ] ) && ( ( arrX[ i + 1 ] + arrY[ i + 1 ] ) > ( arrX[ i ] + arrY[ i ] ) ) )
        j+= 1 
        arrx[ j ] = arrX[ j + 1 ]
        arry[ j ] = arry[ j + 1 ]
    if( ( arrX[ i + 1 ] - arrY[ i + 1 ] ) < ( arrX[ i + 2 ] - arrY[ i + 2 ] ) && ( ( arrX[ i + 1 ] - arrY[ i + 1 ] ) < ( arrX[ i ] - arrY[ i ] ) ) )
        j+= 1
        arrx[ j ] = arrX[ j + 1 ]
        arry[ j ] = arry[ j + 1 ]
    if( ( arrX[ i + 1 ] - arrY[ i + 1 ] ) > ( arrX[ i + 2 ] - arrY[ i + 2 ] ) && ( ( arrX[ i + 1 ] - arrY[ i + 1 ] ) > ( arrX[ i ] - arrY[ i ] ) ) )
        j++ 
        arrx[ j ] = arrX[ j + 1 ]
        arry[ j ] = arry[ j + 1 ]
    i+= 1
    
j+= 1
arrx[ j ] = arrX[ arrX.length( ) - 1 ]
arry[ j ] = arrY[ arry.length( ) - 1 ]

u1 , u2 , u3 , u4 , u5 , u6 , u7 , u8
theta

length = 0
i = 0 
for i in range( arrx.length( ) - 1 ) :
    length += dist( arrx[ i + 1 ] - arrx[ i ] )
    i+= 1
i = 0
for i in range( arrx.length( ) - 1 ):
    i += 1
    theta = (180/3.14159265359)math.atan( ( arrx[ i + 1 ] - arrx[ i ] )/( arry[ i + 1 ] - arry[ i ] ) )
    if( ( arrx[ i + 1 ] - arrx[ i ] < 0 )&&( arry[ i + 1 ] - arry[ i ] < 0 ) )
        theta += 180
    if( ( arrx[ i + 1 ] - arrx[ i ] < 0 )&&( arry[ i + 1 ] - arry[ i ] > 0 ) )
        theta += 180
    theta += 67.5
    if( -22.5 < theta < 22.5 )
        u1 += dist( arrx[ i + 1 ] - arrx[ i ] )
    if( 22.5 < theta < 67.5 )
        u2 += dist( arrx[ i + 1 ] - arrx[ i ] 
    if( 67.5 < theta < 112.5 )
        u3 += dist( arrx[ i + 1 ] - arrx[ i ] 
    if( 122.5 < theta < 157.5 )
        u4 += dist( arrx[ i + 1 ] - arrx[ i ]
    if( 157.5 < theta < 202.5 )
        u5 += dist( arrx[ i + 1 ] - arrx[ i ]
    if( 202.5 < theta < 247.5 )
        u6 += dist( arrx[ i + 1 ] - arrx[ i ]
    if( 247.5 < theta < 292.5 )
        u7 += dist( arrx[ i + 1 ] - arrx[ i ]
    if( 292.5 < theta < 367.5 )
        u8 += dist( arrx[ i + 1 ] - arrx[ i ]

u1 /= length
u2 /= length
u3 /= length
u4 /= length
u5 /= length
u6 /= length
u7 /= length
u8 /= length
                   
U = vector( u1 , u2 , u3 , u4 , u5 , u6 , u7 , u8 )
mean = vector( x , y , length )
sigx = sig( arrx )
sigy = sig( arry )
ro = pearsonr( arrx , arry )
covar = [ [ sigx^2 , sigx*sigy*ro ] , [ sigx*sigy*ro , sigy^2 ] ]

i = 0 
                   
for i in range( arrx.length( ) ) :
    v = vector( arrx[ i ] , arry[ i ] , length )
    g2v = np.exp( -0.5*( v - mean ).T*inverse( covar )*( v - mean ) )/( ( ( 2*3.14159 )^1.5 )*( (sigx^2)*(sigy^2)*( 1 - ro^2 ) ) )
    i++

x1 , x2 , x3 , x4 , x5 , x6 , x7 , x8
                   
j = 1 
i = 0
                   
j*= ( mean( u1 )*( 1 - mean( u1 ) )/( sig( u1 )**2 ) - 1 )**( 1 / 7 )
j*= ( mean( u2 )*( 1 - mean( u2 ) )/( sig( u2 )**2 ) - 1 )**( 1 / 7 )
j*= ( mean( u3 )*( 1 - mean( u3 ) )/( sig( u3 )**2 ) - 1 )**( 1 / 7 )
j*= ( mean( u4 )*( 1 - mean( u4 ) )/( sig( u4 )**2 ) - 1 )**( 1 / 7 )
j*= ( mean( u5 )*( 1 - mean( u5 ) )/( sig( u5 )**2 ) - 1 )**( 1 / 7 )
j*= ( mean( u6 )*( 1 - mean( u6 ) )/( sig( u6 )**2 ) - 1 )**( 1 / 7 )
j*= ( mean( u7 )*( 1 - mean( u7 ) )/( sig( u7 )**2 ) - 1 )**( 1 / 7 )
                   
x1 = j
x2 = x1*mean( u2 ) 
x3 = x1*mean( u3 ) 
x4 = x1*mean( u4 ) 
x5 = x1*mean( u5 ) 
x6 = x1*mean( u6 ) 
x7 = x1*mean( u7 ) 
x8 = x1*mean( u8 ) 
                   
g1u = ( math.gamma( x1 + x2 + x3 + x4 + x5 + x6 + x7 + x8 )*( u1**( x1 - 1 ) )*u2**( x2 - 1 ) )*u3**( x3 - 1 ) )*u4**( x4 - 1 ) )*u5**( x5 - 1 ) )*u6**( x6 - 1 ) )*u7**( x7 - 1 ) )*u8**( x8 - 1 ) ) )/math.gamma( x1*x2*x3*x4*x5*x6*x7*x8 )

import numpy as np
from sklearn import hmm

model = hmm.GaussianHMM(3, "full", startprob, transmat)

model2 = hmm.GaussianHMM(3, "full")
model2.fit([X]) 

Z2 = model2.predict(X)
