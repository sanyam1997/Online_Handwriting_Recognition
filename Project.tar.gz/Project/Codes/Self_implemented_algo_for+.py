i = 0 
s_0 = 0.0
f_0 = 0.0 
for i in range( 25 ) :
    if( arrX[ i ] == arrX[ i + 1 ] ) :
        s_0 += 1.0
    else :
        f_0 += 1.0
i = 0
s_1 = 0.0 
f_1 = 0.0
for i in range( 45 ) :
    if( arry1[ i ] == arry1[ i + 1 ] ) :
        s_1 += 1.0
    else :
        f_1 += 1.0
s_0 , f_0 , s_0 /( s_0 + f_0 ) , s_1 , f_1 , s_1/( s_1 + f_1 )
if( ( s_0 /( s_0 + f_0 ) + s_1/( s_1 + f_1 ) )/2 > 0.5 ) :
    print "accuracy"
    acc = ( s_0 /( s_0 + f_0 ) + s_1/( s_1 + f_1 ) )/2
    print acc
